//Basit Rashid, S1430758
package com.rss.testapp;

import android.os.Build;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.rss.testapp.model.RSSItem;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


public class RssFeedListAdapter
        extends RecyclerView.Adapter<RssFeedListAdapter.FeedModelViewHolder> implements Filterable {

    private List<RSSItem> mRssFeedModels = new ArrayList<>();
    private List<RSSItem> mRssFeedListFiltered = new ArrayList<>();

    static class FeedModelViewHolder extends RecyclerView.ViewHolder {
        private View rssFeedView;

        FeedModelViewHolder(View v) {
            super(v);
            rssFeedView = v;
        }
    }

    void updateFeeds(List<RSSItem> mRssFeedModels) {
        this.mRssFeedModels = mRssFeedModels;
        this.mRssFeedListFiltered = mRssFeedModels;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public FeedModelViewHolder onCreateViewHolder(ViewGroup parent, int type) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.rss_item_list_row, parent, false);
        return new FeedModelViewHolder(v);
    }

    @Override
    public void onBindViewHolder(FeedModelViewHolder holder, int position) {
        final RSSItem rssFeedModel = mRssFeedListFiltered.get(position);
        ((TextView) holder.rssFeedView.findViewById(R.id.title)).setText(rssFeedModel.title);
        ((TextView) holder.rssFeedView.findViewById(R.id.description)).setText(rssFeedModel.description);
        ((TextView) holder.rssFeedView.findViewById(R.id.page_url)).setText(rssFeedModel.link);
        ((TextView) holder.rssFeedView.findViewById(R.id.pub_date)).setText(rssFeedModel.pubdate);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            ((TextView) holder.rssFeedView.findViewById(R.id.description)).setText(Html.fromHtml(rssFeedModel.description, Html.FROM_HTML_MODE_COMPACT));
        } else {
            ((TextView) holder.rssFeedView.findViewById(R.id.description)).setText(Html.fromHtml(rssFeedModel.description));

        }
    }

    @Override
    public int getItemCount() {
        return mRssFeedListFiltered.size();
    }

    @Override
    public Filter getFilter() {
        return new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence charSequence) {
                String charString = charSequence.toString();
                if (charString.isEmpty()) {
                    mRssFeedListFiltered = mRssFeedModels;
                } else {
                    List<RSSItem> filteredList = new ArrayList<>();
                    for (RSSItem row : mRssFeedModels) {

                        if (row.title.toLowerCase().contains(charString.toLowerCase())) {
                            filteredList.add(row);
                        }
                    }

                    mRssFeedListFiltered = filteredList;
                }

                FilterResults filterResults = new FilterResults();
                filterResults.values = mRssFeedListFiltered;
                return filterResults;
            }

            @Override
            protected void publishResults(CharSequence charSequence, FilterResults filterResults) {
                mRssFeedListFiltered = (List<RSSItem>) filterResults.values;
                notifyDataSetChanged();
            }
        };
    }

}

